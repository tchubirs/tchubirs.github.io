# Cinco anúncios para publicar à mão na Etsy

Opcional: só se quiser pôr estas 5 planilhas à venda sem esperar o app da Etsy.
Cerca de 5 minutos cada. Na Etsy: Shop Manager > Listings > Add a listing.

Para cada pasta, em ordem:
1. Fotos: envie as imagens da pasta `fotos`, na ordem dos números.
2. Arquivos: envie os 2 arquivos da pasta `arquivos`.
3. Textos: copie cada bloco de `textos-para-copiar.md` para o campo de mesmo nome.

Quando o app da Etsy for aprovado, eu publico as outras sozinho e pulo estas 5.
